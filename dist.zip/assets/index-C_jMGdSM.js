import{_ as e,b as c,c as n}from"./index-CllOzf_8.js";const s={},t={class:"index"};function o(r,_){return c(),n("div",t,"数据中心")}const d=e(s,[["render",o]]);export{d as default};
